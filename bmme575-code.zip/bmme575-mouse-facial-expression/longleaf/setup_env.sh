#!/bin/bash
# ONE-TIME setup: creates a Python environment with PyTorch and caches the
# SqueezeNet ImageNet weights. Run it inside an interactive session (see guide):
#   srun -t 2:00:00 -p interact -n 1 --cpus-per-task=4 --mem=16g --pty /bin/bash
#   bash longleaf/setup_env.sh
set -e
source "$(dirname "$0")/env.sh"
echo "Project folder: $PROJ"

if [ ! -x "$ENV/bin/python" ]; then
    conda create -y -p "$ENV" python=3.11
fi
# PyTorch built for CUDA 12.1 runs on Longleaf's A100 / L40 GPUs
$PY -m pip install --upgrade pip
$PY -m pip install torch==2.5.1 torchvision==0.20.1 --index-url https://download.pytorch.org/whl/cu121
$PY -m pip install numpy pandas scikit-learn scikit-image opencv-python-headless matplotlib joblib

# Download SqueezeNet ImageNet weights now, so GPU jobs never need the internet
$PY -c "from torchvision import models; models.squeezenet1_1(weights='IMAGENET1K_V1'); print('ImageNet weights cached in $TORCH_HOME')"
$PY -c "import torch, torchvision, sklearn, skimage, cv2; print('torch', torch.__version__, '| torchvision', torchvision.__version__, '| OK')"
echo "Setup finished."
