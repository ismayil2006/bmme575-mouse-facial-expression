# Shared settings, sourced by every Longleaf script. Nothing to edit here.

# Find your personal scratch space (/work for older accounts, /hickory for new ones)
O=${USER:0:1}; N=${USER:1:1}
WORK=""
for d in /work/users/$O/$N/$USER /hickory/users/$O/$N/$USER /users/$O/$N/$USER; do
    if [ -d "$d" ] && [ -w "$d" ]; then WORK=$d; break; fi
done
if [ -z "$WORK" ]; then
    echo "Could not find your /work, /hickory/users or /users folder. Email research@unc.edu." >&2
    return 1 2>/dev/null || exit 1
fi

PROJ=$WORK/bmme575
CODE=$PROJ/mouse_face_pr2
DATA=$PROJ/data
ENV=$PROJ/conda_env
PY=$ENV/bin/python                       # the project Python (no "conda activate" needed)
export TORCH_HOME=$PROJ/torch_cache      # ImageNet weights are cached here (not in home)
export PIP_CACHE_DIR=$PROJ/pip_cache
mkdir -p "$PROJ" "$DATA" "$TORCH_HOME" "$PIP_CACHE_DIR"

module purge
module load anaconda/2024.02
