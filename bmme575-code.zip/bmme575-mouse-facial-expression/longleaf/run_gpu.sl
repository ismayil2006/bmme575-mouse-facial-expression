#!/bin/bash
#SBATCH -J pr2_mouse_face
#SBATCH -p l40-gpu,a100-gpu          # whichever GPU frees up first
#SBATCH --qos=gpu_access
#SBATCH --gres=gpu:1
#SBATCH -n 1
#SBATCH --cpus-per-task=8
#SBATCH --mem=32g
#SBATCH -t 4:00:00
#SBATCH -o logs/run_%j.out
##SBATCH --mail-type=end,fail          # remove one '#' to get an e-mail
##SBATCH --mail-user=ONYEN@email.unc.edu

# ======================= INPUTS (defaults = what we used) ===================
FRAMES="DATA_DIR/20200121_mouseFacialExpr_v1/sh200_32"   # 200 uA tail-shock frames
CROP="89 264 1144 586"                                 # authors' head crop
# ============================================================================
EXTRA_ARGS=""     # e.g. "--optimizer adam --lr 1e-4"  or  "--skip-cnn"

set -e
source longleaf/env.sh
FRAMES=${FRAMES/DATA_DIR/$DATA}
echo "Node: $(hostname)   Job: $SLURM_JOB_ID"; nvidia-smi --query-gpu=name,memory.total --format=csv || true

OUT=results_$SLURM_JOB_ID
$PY run_pipeline.py --frames "$FRAMES" --crop $CROP --out "$OUT" --workers 6 $EXTRA_ARGS

$PY -c "import shutil; shutil.make_archive('$OUT', 'zip', '.', '$OUT')"
echo "Results: $(pwd)/$OUT   (zipped: $OUT.zip)"
