"""
Save a PNG of one frame with a pixel grid (and the crop box, if given), so you
can choose the head crop without a display. Open the PNG in OnDemand's file browser.

  python longleaf/preview_frame.py --frames /path/to/frames
  python longleaf/preview_frame.py --frames /path/to/frames --crop 300 100 640 480
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from src.data import FrameSource

ap = argparse.ArgumentParser()
ap.add_argument("--frames", required=True)
ap.add_argument("--crop", nargs=4, type=int)
ap.add_argument("--index", type=int, nargs="+", default=[3500, 3630])
ap.add_argument("--out", default="crop_preview.png")
a = ap.parse_args()

src = FrameSource(a.frames)
print("frames in recording:", len(src), "(needs > 10980)")
imgs = src.read(a.index)
print("frame size (h, w):", imgs.shape[1:])
ncol = len(imgs) + (len(imgs) if a.crop else 0)
fig, axes = plt.subplots(1, ncol, figsize=(7 * ncol, 6))
for k, (i, img) in enumerate(zip(a.index, imgs)):
    ax = axes[k]
    ax.imshow(img, cmap="gray")
    ax.set_xticks(range(0, img.shape[1], 50)); ax.set_yticks(range(0, img.shape[0], 50))
    ax.tick_params(labelsize=6, labelrotation=90); ax.grid(alpha=0.35, color="yellow")
    ax.set_title(f"frame {i}  ({'pre-shock' if i < 3600 else 'during shock'})")
    if a.crop:
        x, y, w, h = a.crop
        ax.add_patch(patches.Rectangle((x, y), w, h, fill=False, ec="red", lw=2))
        axes[len(imgs) + k].imshow(img[y:y + h, x:x + w], cmap="gray")
        axes[len(imgs) + k].set_title(f"cropped frame {i}")
fig.savefig(a.out, dpi=110, bbox_inches="tight")
print("saved", os.path.abspath(a.out))
