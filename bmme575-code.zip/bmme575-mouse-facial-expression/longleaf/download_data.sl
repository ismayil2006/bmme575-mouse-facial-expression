#!/bin/bash
#SBATCH -J pr2_download
#SBATCH -p datamover
#SBATCH -n 1
#SBATCH --cpus-per-task=2
#SBATCH --mem=8g
#SBATCH -t 3:00:00
#SBATCH -o logs/download_%j.out
# Downloads the Dolensek et al. (2020) archive from Zenodo, unzips it, and lists
# every folder that contains video frames. Submit from the mouse_face_pr2 folder:
#   sbatch longleaf/download_data.sl
set -e
source longleaf/env.sh
RECORD=${RECORD:-3618395}
cd "$DATA"

python - "$RECORD" <<'EOF'
import json, sys, urllib.request, os
rec = sys.argv[1]
files = json.load(urllib.request.urlopen(f"https://zenodo.org/api/records/{rec}"))["files"]
for f in files:
    print(f"{f['key']:60s} {f['size']/1e6:9.1f} MB")
    if not os.path.exists(f["key"]) or os.path.getsize(f["key"]) != f["size"]:
        print("  downloading ...", flush=True)
        urllib.request.urlretrieve(f["links"]["self"], f["key"])
EOF

for z in *.zip; do [ -e "$z" ] && unzip -oq "$z" && echo "unzipped $z"; done
for t in *.tar* *.tgz; do [ -e "$t" ] && tar -xf "$t" && echo "extracted $t"; done

echo; echo "=== Folders containing frames (count  path) ==="
find "$DATA" -type f \( -iname '*.jpg' -o -iname '*.png' -o -iname '*.tif' \) -printf '%h\n' \
    | sort | uniq -c | sort -rn | tee "$PROJ/frame_folders.txt"
echo; echo "=== Video files ==="
find "$DATA" -type f \( -iname '*.mp4' -o -iname '*.avi' -o -iname '*.mov' \) | tee -a "$PROJ/frame_folders.txt"
echo "List saved to $PROJ/frame_folders.txt"
