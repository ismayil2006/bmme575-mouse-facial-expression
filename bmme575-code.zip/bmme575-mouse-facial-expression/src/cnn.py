"""
CNN classifier: SqueezeNet v1.1 fine-tuned from ImageNet weights, following
Tanaka et al. (2023, PLOS ONE) - SGD with momentum, lr 3e-4, cross-entropy,
random vertical flip and random translation up to 30 px.
"""
from __future__ import annotations

import copy
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from torchvision import models
from torchvision.transforms import v2 as T

from .config import Config

IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]


def device():
    if torch.cuda.is_available():
        return torch.device("cuda")
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def set_seed(seed: int):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# ------------------------------------------------------------------- data
def _to3(x):
    return x.expand(3, -1, -1)


class FaceFrames(Dataset):
    def __init__(self, images: np.ndarray, y: np.ndarray, cfg: Config, train: bool):
        self.images, self.y = images, y
        s = cfg.img_size
        # translation of 30 px in the 224-px input space
        frac = cfg.aug_translate_px / s
        aug = []
        if train:
            if cfg.aug_vflip:
                aug.append(T.RandomVerticalFlip())
            aug.append(T.RandomAffine(degrees=0, translate=(frac, frac)))
        self.tf = T.Compose([
            T.ToImage(),
            T.Resize((s, s), antialias=True),
            *aug,
            T.ToDtype(torch.float32, scale=True),
            T.Lambda(_to3),                              # grayscale -> 3 channels
            T.Normalize(IMAGENET_MEAN, IMAGENET_STD),
        ])

    def __len__(self):
        return len(self.y)

    def __getitem__(self, i):
        return self.tf(self.images[i][..., None]), int(self.y[i])


# ------------------------------------------------------------------ model
def build_squeezenet(pretrained: bool = True, n_classes: int = 2) -> nn.Module:
    w = models.SqueezeNet1_1_Weights.IMAGENET1K_V1 if pretrained else None
    try:
        net = models.squeezenet1_1(weights=w)
    except Exception as e:  # no internet -> fall back to random init
        print(f"[warn] could not load ImageNet weights ({e}); training from scratch")
        net = models.squeezenet1_1(weights=None)
    # replace the final 1x1 conv classifier (1000 ImageNet classes -> 2)
    net.classifier[1] = nn.Conv2d(512, n_classes, kernel_size=1)
    nn.init.normal_(net.classifier[1].weight, std=0.01)
    nn.init.zeros_(net.classifier[1].bias)
    # SqueezeNet ends with ReLU -> avg-pool. With a freshly initialised 2-class
    # layer the ReLU can zero every logit ("dead" outputs, loss stuck at ln 2),
    # so we drop it and let the logits take negative values.
    net.classifier[2] = nn.Identity()
    net.num_classes = n_classes
    return net


# --------------------------------------------------------------- training
def _run_epoch(net, loader, dev, opt=None, loss_fn=None):
    train = opt is not None
    net.train(train)
    tot, n, correct = 0.0, 0, 0
    with torch.set_grad_enabled(train):
        for xb, yb in loader:
            xb, yb = xb.to(dev), yb.to(dev)
            logits = net(xb)
            loss = loss_fn(logits, yb)
            if train:
                opt.zero_grad()
                loss.backward()
                opt.step()
            tot += loss.item() * len(yb)
            n += len(yb)
            correct += (logits.argmax(1) == yb).sum().item()
    return tot / n, correct / n


def train_cnn(images, y, split, cfg: Config, verbose=True):
    """Train on split['train'], early-stop on split['val']. Returns (model, history)."""
    set_seed(cfg.seed)
    dev = device()
    tr = FaceFrames(images[split["train"]], y[split["train"]], cfg, train=True)
    va = FaceFrames(images[split["val"]], y[split["val"]], cfg, train=False)
    pin = dev.type == "cuda"
    dl_tr = DataLoader(tr, batch_size=cfg.cnn_batch_size, shuffle=True,
                       num_workers=cfg.num_workers, pin_memory=pin)
    dl_va = DataLoader(va, batch_size=64, num_workers=cfg.num_workers, pin_memory=pin)

    net = build_squeezenet(cfg.cnn_pretrained).to(dev)
    # class weights counter the 2:1 pre/during imbalance
    counts = np.bincount(y[split["train"]], minlength=2)
    w = torch.tensor(counts.sum() / (2 * np.maximum(counts, 1)), dtype=torch.float32)
    loss_fn = nn.CrossEntropyLoss(weight=w.to(dev))
    if cfg.cnn_optimizer == "adam":
        opt = torch.optim.Adam(net.parameters(), lr=cfg.cnn_lr)
    else:
        opt = torch.optim.SGD(net.parameters(), lr=cfg.cnn_lr, momentum=cfg.cnn_momentum)

    hist = {"epoch": [], "train_loss": [], "train_acc": [], "val_loss": [], "val_acc": []}
    best, best_state, wait = np.inf, None, 0
    t0 = time.time()
    for ep in range(1, cfg.cnn_epochs + 1):
        tl, ta = _run_epoch(net, dl_tr, dev, opt, loss_fn)
        vl, vacc = _run_epoch(net, dl_va, dev, None, loss_fn)
        for k, v in zip(hist, (ep, tl, ta, vl, vacc)):
            hist[k].append(v)
        if vl < best - 1e-4:
            best, best_state, wait = vl, copy.deepcopy(net.state_dict()), 0
        else:
            wait += 1
        if verbose and (ep == 1 or ep % 5 == 0):
            print(f"  ep {ep:3d}  train {tl:.3f}/{ta:.3f}  val {vl:.3f}/{vacc:.3f}"
                  f"  ({time.time() - t0:.0f}s)")
        if wait >= cfg.cnn_patience:
            if verbose:
                print(f"  early stop at epoch {ep} (best val loss {best:.3f})")
            break
    net.load_state_dict(best_state)
    return net, hist


@torch.no_grad()
def predict_cnn(net, images, cfg: Config):
    dev = next(net.parameters()).device
    ds = FaceFrames(images, np.zeros(len(images), int), cfg, train=False)
    dl = DataLoader(ds, batch_size=64, num_workers=cfg.num_workers)
    net.eval()
    probs = []
    for xb, _ in dl:
        probs.append(F.softmax(net(xb.to(dev)), 1)[:, 1].cpu().numpy())
    p = np.concatenate(probs)
    return (p >= 0.5).astype(int), p
