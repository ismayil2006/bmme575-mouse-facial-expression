"""
Dolensek et al. (2020) methods: HOG descriptors, Random-Forest classifier,
and prototype-similarity analysis (Pearson correlation of each frame's HOG
with an emotion "prototype" face).
"""
from __future__ import annotations

import numpy as np
from joblib import Parallel, delayed
from skimage.feature import hog
from sklearn.ensemble import RandomForestClassifier

from .config import Config


# ------------------------------------------------------------------------- HOG
def hog_one(img: np.ndarray, cfg: Config) -> np.ndarray:
    return hog(img,
               orientations=cfg.hog_orientations,
               pixels_per_cell=(cfg.hog_pixels_per_cell, cfg.hog_pixels_per_cell),
               cells_per_block=(cfg.hog_cells_per_block, cfg.hog_cells_per_block),
               feature_vector=True)


def hog_features(images: np.ndarray, cfg: Config, n_jobs: int = -1) -> np.ndarray:
    feats = Parallel(n_jobs=n_jobs)(delayed(hog_one)(im, cfg) for im in images)
    return np.asarray(feats, dtype=np.float32)


def hog_image(img: np.ndarray, cfg: Config) -> np.ndarray:
    """HOG visualisation (for the figure showing what the features look like)."""
    _, vis = hog(img, orientations=cfg.hog_orientations,
                 pixels_per_cell=(cfg.hog_pixels_per_cell, cfg.hog_pixels_per_cell),
                 cells_per_block=(cfg.hog_cells_per_block, cfg.hog_cells_per_block),
                 visualize=True)
    return vis


# ----------------------------------------------------------------- Random Forest
def train_rf(X_tr, y_tr, cfg: Config) -> RandomForestClassifier:
    rf = RandomForestClassifier(n_estimators=cfg.rf_n_estimators,
                                random_state=cfg.seed, n_jobs=-1)
    rf.fit(X_tr, y_tr)
    return rf


# ------------------------------------------------------- prototype similarity
def _zscore_rows(X):
    X = X - X.mean(1, keepdims=True)
    return X / (X.std(1, keepdims=True) + 1e-8)


def pearson_to(X: np.ndarray, proto: np.ndarray) -> np.ndarray:
    """Pearson r between every row of X and a prototype vector."""
    return (_zscore_rows(X) @ _zscore_rows(proto[None])[0]) / X.shape[1]


class PrototypeClassifier:
    """
    Paper-style similarity classifier. A prototype is the mean HOG of the
    training frames of each class; a frame is assigned to the class whose
    prototype it correlates with most. The score used for ROC is
    r(pain prototype) - r(neutral prototype).
    """

    def fit(self, X, y):
        self.protos_ = np.stack([X[y == c].mean(0) for c in (0, 1)])
        return self

    def similarity(self, X):
        return np.stack([pearson_to(X, p) for p in self.protos_], 1)

    def decision_function(self, X):
        s = self.similarity(X)
        return s[:, 1] - s[:, 0]

    def predict(self, X):
        return (self.decision_function(X) > 0).astype(int)
