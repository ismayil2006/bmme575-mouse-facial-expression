"""Objective assessment: accuracy, sensitivity/specificity, precision/recall,
F1, ROC-AUC, confusion matrix and bootstrap 95% confidence intervals."""
from __future__ import annotations

import numpy as np
from sklearn import metrics as skm


def binary_metrics(y_true, y_pred, score=None) -> dict:
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    tn, fp, fn, tp = skm.confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    m = {
        "accuracy": (tp + tn) / len(y_true),
        "balanced_accuracy": skm.balanced_accuracy_score(y_true, y_pred),
        "sensitivity": tp / (tp + fn) if tp + fn else np.nan,  # recall of during-shock
        "specificity": tn / (tn + fp) if tn + fp else np.nan,  # recall of pre-shock
        "precision_shock": tp / (tp + fp) if tp + fp else np.nan,
        "precision_pre": tn / (tn + fn) if tn + fn else np.nan,
        "f1_shock": skm.f1_score(y_true, y_pred, zero_division=0),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
    }
    if score is not None and len(np.unique(y_true)) == 2:
        m["roc_auc"] = skm.roc_auc_score(y_true, score)
    return m


def bootstrap_ci(y_true, y_pred, score=None, n_boot=1000, seed=0,
                 keys=("accuracy", "balanced_accuracy", "sensitivity",
                       "specificity", "f1_shock", "roc_auc")) -> dict:
    """Percentile 95% CI by resampling test frames with replacement.
    Note: consecutive frames are correlated, so these CIs are optimistic."""
    rng = np.random.default_rng(seed)
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    score = None if score is None else np.asarray(score)
    vals = {k: [] for k in keys}
    n = len(y_true)
    for _ in range(n_boot):
        i = rng.integers(0, n, n)
        if len(np.unique(y_true[i])) < 2:
            continue
        m = binary_metrics(y_true[i], y_pred[i], None if score is None else score[i])
        for k in keys:
            if k in m:
                vals[k].append(m[k])
    return {k: (np.nanpercentile(v, 2.5), np.nanpercentile(v, 97.5))
            for k, v in vals.items() if v}


def summarize(name, split_name, y_true, y_pred, score=None, ci=True) -> dict:
    row = {"model": name, "split": split_name, "n_test": len(y_true)}
    row.update(binary_metrics(y_true, y_pred, score))
    if ci:
        for k, (lo, hi) in bootstrap_ci(y_true, y_pred, score).items():
            row[f"{k}_ci"] = f"[{lo:.3f}, {hi:.3f}]"
    return row
