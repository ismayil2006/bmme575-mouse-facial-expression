"""
Central configuration for BMME 575 Progress Report 2.

Edit the paths and the CROP box for your machine / Colab. Everything else
follows Dolensek et al. (2020) and the plan in Progress Report 1.
"""
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Config:
    # ------------------------------------------------------------------ data
    # Folder of extracted video frames (*.jpg / *.png) for the 200 uA tail-shock
    # recording from the Dolensek Zenodo archive, OR a single video file.
    frames_source: str = "data/20200121_mouseFacialExpr_v1/sh200_32"
    frame_glob: str = "*.jpg"

    # Head crop box (x, y, w, h) in pixels, same convention as the authors'
    # findCropCoords(). Default = the authors' own crop for this recording.
    crop: tuple | None = (89, 264, 1144, 586)   # authors' crop (proto_cropCoords.pkl)

    # Shock onsets (frame index) and windows, as in Progress Report 1.
    shock_onsets: tuple = (3600, 7260, 10920)
    n_pre: int = 120      # frames before shock  -> label 0 (pre-shock / neutral)
    n_during: int = 60    # frames during shock  -> label 1 (during-shock / pain)

    # ----------------------------------------------------------------- HOG
    # Dolensek et al.: 8 orientations, 32x32-pixel cells, 1x1 blocks.
    hog_orientations: int = 8
    hog_pixels_per_cell: int = 32
    hog_cells_per_block: int = 1

    # --------------------------------------------------------------- splits
    seed: int = 42
    train_frac: float = 0.15   # paper: random 15% of frames used for training

    # ----------------------------------------------------------- RF baseline
    rf_n_estimators: int = 100     # sklearn default, as in the authors' notebook

    # ------------------------------------------------------------------ CNN
    # SqueezeNet v1.1 fine-tuned from ImageNet, following Tanaka et al. (2023).
    img_size: int = 224
    cnn_pretrained: bool = True
    cnn_optimizer: str = "sgd"     # "sgd" (Tanaka et al.) or "adam"
    cnn_lr: float = 3e-4           # Tanaka et al.
    cnn_momentum: float = 0.9      # SGD with momentum (Tanaka et al.)
    cnn_batch_size: int = 32       # Tanaka used 512; our training set is only 81 frames
    cnn_epochs: int = 60
    cnn_patience: int = 15         # early stopping on validation loss
    aug_translate_px: int = 30     # Tanaka: random translation up to 30 px
    aug_vflip: bool = True         # Tanaka: random vertical flip
    num_workers: int = 2

    # --------------------------------------------------------------- output
    out_dir: str = "results"

    @property
    def out(self) -> Path:
        p = Path(self.out_dir)
        p.mkdir(parents=True, exist_ok=True)
        return p
