"""
Frame loading, labelling and train/validation/test splits.

Input can be either a folder of extracted frames (natural-sorted by file name,
frame 0 = first file) or a single video file. Only the frames that are needed
are loaded, so the 1 GB archive never has to sit in memory.
"""
from __future__ import annotations

import glob
import os
import re
from dataclasses import dataclass

import cv2
import numpy as np
from sklearn.model_selection import train_test_split

from .config import Config


# --------------------------------------------------------------------------- io
def _natural_key(s: str):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", s)]


class FrameSource:
    """Random access to frames of a recording (folder of images or a video)."""

    def __init__(self, source: str, pattern: str = "*.jpg"):
        self.source = source
        self.is_video = os.path.isfile(source)
        if self.is_video:
            cap = cv2.VideoCapture(source)
            if not cap.isOpened():
                raise FileNotFoundError(f"Cannot open video {source}")
            self.n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            cap.release()
        else:
            files = glob.glob(os.path.join(source, pattern))
            if not files:  # try common alternatives before failing
                for alt in ("*.png", "*.jpg", "*.jpeg", "*.tif", "*.bmp"):
                    files = glob.glob(os.path.join(source, alt))
                    if files:
                        break
            if not files:
                raise FileNotFoundError(f"No frames matching {pattern} in {source}")
            self.files = sorted(files, key=_natural_key)
            self.n = len(self.files)

    def __len__(self):
        return self.n

    def read(self, indices) -> np.ndarray:
        """Return grayscale uint8 frames, shape (len(indices), H, W)."""
        indices = list(indices)
        if max(indices) >= self.n:
            raise IndexError(f"Frame {max(indices)} requested but recording has {self.n} frames")
        if self.is_video:
            cap = cv2.VideoCapture(self.source)
            out, cur = [], -1
            for i in indices:  # indices are sorted windows -> sequential reads are fast
                if i != cur + 1:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, i)
                ok, fr = cap.read()
                if not ok:
                    raise IOError(f"Failed reading frame {i}")
                out.append(cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY))
                cur = i
            cap.release()
            return np.stack(out)
        return np.stack([cv2.imread(self.files[i], cv2.IMREAD_GRAYSCALE) for i in indices])


def crop_frames(frames: np.ndarray, crop) -> np.ndarray:
    if crop is None:
        return frames
    x, y, w, h = map(int, crop)
    return frames[:, y:y + h, x:x + w]


def pick_crop(cfg: Config, frame_index: int | None = None):
    """Interactively draw the head box on one frame (needs a display)."""
    src = FrameSource(cfg.frames_source, cfg.frame_glob)
    idx = frame_index if frame_index is not None else cfg.shock_onsets[0]
    img = src.read([idx])[0]
    box = cv2.selectROI("Draw head crop, then ENTER", img, showCrosshair=True)
    cv2.destroyAllWindows()
    print("crop =", tuple(int(v) for v in box))
    return tuple(int(v) for v in box)


# ---------------------------------------------------------------------- dataset
@dataclass
class ShockDataset:
    images: np.ndarray       # (N, H, W) uint8, cropped head region
    y: np.ndarray            # (N,) 0 = pre-shock, 1 = during-shock
    trial: np.ndarray        # (N,) 0, 1, 2  (shock presentation)
    frame_idx: np.ndarray    # (N,) absolute frame number in the recording
    t_rel: np.ndarray        # (N,) frame index relative to shock onset


def window_indices(cfg: Config):
    """Frames 3480-3659, 7140-7319, 10800-10979 for the default config."""
    idx, y, trial, t_rel = [], [], [], []
    for k, on in enumerate(cfg.shock_onsets):
        r = np.arange(on - cfg.n_pre, on + cfg.n_during)
        idx.append(r)
        y.append(np.r_[np.zeros(cfg.n_pre, int), np.ones(cfg.n_during, int)])
        trial.append(np.full(len(r), k))
        t_rel.append(r - on)
    return (np.concatenate(idx), np.concatenate(y),
            np.concatenate(trial), np.concatenate(t_rel))


def load_shock_dataset(cfg: Config) -> ShockDataset:
    src = FrameSource(cfg.frames_source, cfg.frame_glob)
    idx, y, trial, t_rel = window_indices(cfg)
    imgs = crop_frames(src.read(idx), cfg.crop)
    return ShockDataset(imgs, y, trial, idx, t_rel)


def load_timecourse(cfg: Config, before: int = 300, after: int = 300):
    """Longer windows around every shock, used for the similarity time course."""
    src = FrameSource(cfg.frames_source, cfg.frame_glob)
    out = []
    for on in cfg.shock_onsets:
        lo, hi = max(0, on - before), min(len(src), on + after)
        out.append((np.arange(lo, hi) - on, crop_frames(src.read(range(lo, hi)), cfg.crop)))
    return out


# ----------------------------------------------------------------------- splits
def split_stratified(y: np.ndarray, cfg: Config):
    """Progress Report 1 split: 15% train, rest halved into val / test (stratified)."""
    idx = np.arange(len(y))
    tr, rest = train_test_split(idx, train_size=cfg.train_frac, stratify=y,
                                random_state=cfg.seed)
    va, te = train_test_split(rest, test_size=0.5, stratify=y[rest],
                              random_state=cfg.seed)
    _check(tr, va, te, len(y))
    return {"train": tr, "val": va, "test": te}


def split_trialwise(trial: np.ndarray):
    """Stricter split: train on shock 1, validate on shock 2, test on shock 3."""
    tr, va, te = (np.where(trial == k)[0] for k in (0, 1, 2))
    _check(tr, va, te, len(trial))
    return {"train": tr, "val": va, "test": te}


def splits_leave_one_trial_out(y: np.ndarray, trial: np.ndarray, cfg: Config):
    """3 folds: test on one shock presentation, train/val on the other two."""
    folds = []
    for k in np.unique(trial):
        te = np.where(trial == k)[0]
        rest = np.where(trial != k)[0]
        tr, va = train_test_split(rest, test_size=0.2, stratify=y[rest],
                                  random_state=cfg.seed)
        _check(tr, va, te, len(y))
        folds.append({"train": tr, "val": va, "test": te, "name": f"test_on_shock{k + 1}"})
    return folds


def _check(tr, va, te, n):
    assert not (set(tr) & set(va)) and not (set(tr) & set(te)) and not (set(va) & set(te))
    assert len(tr) + len(va) + len(te) == n


def split_table(y, split) -> "pd.DataFrame":
    import pandas as pd
    rows = []
    for name in ("train", "val", "test"):
        s = split[name]
        rows.append({"set": name, "n_frames": len(s), "n_pre": int((y[s] == 0).sum()),
                     "n_during": int((y[s] == 1).sum()),
                     "pct_during": round(100 * y[s].mean(), 1)})
    return pd.DataFrame(rows)
