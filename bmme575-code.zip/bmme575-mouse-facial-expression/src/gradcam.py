"""Grad-CAM (Selvaraju et al., 2017) for SqueezeNet, as used by Tanaka et al.
(2023) to see which facial regions drive the classification."""
from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F

from .cnn import FaceFrames
from .config import Config


def gradcam(net, images: np.ndarray, cfg: Config, target_class: int = 1,
            layer=None) -> np.ndarray:
    """Returns heatmaps in [0, 1], shape (N, img_size, img_size)."""
    layer = layer or net.features[-1]          # last Fire module
    dev = next(net.parameters()).device
    acts, grads = {}, {}
    h1 = layer.register_forward_hook(lambda m, i, o: acts.__setitem__("a", o))
    h2 = layer.register_full_backward_hook(lambda m, gi, go: grads.__setitem__("g", go[0]))
    ds = FaceFrames(images, np.zeros(len(images), int), cfg, train=False)
    net.eval()
    maps = []
    try:
        for i in range(len(ds)):
            x = ds[i][0][None].to(dev).requires_grad_(True)
            net.zero_grad()
            net(x)[0, target_class].backward()
            w = grads["g"].mean(dim=(2, 3), keepdim=True)
            cam = F.relu((w * acts["a"]).sum(1, keepdim=True))
            cam = F.interpolate(cam, size=(cfg.img_size, cfg.img_size),
                                mode="bilinear", align_corners=False)[0, 0]
            cam = cam - cam.min()
            maps.append((cam / (cam.max() + 1e-8)).detach().cpu().numpy())
    finally:
        h1.remove()
        h2.remove()
    return np.stack(maps)
