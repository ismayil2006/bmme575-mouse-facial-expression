"""
BMME 575 - Progress Report 2 pipeline.

Runs, on the Dolensek et al. (2020) 200 uA tail-shock recording:
  1. Paper reproduction: HOG + Random Forest (authors' exact protocol)
  2. HOG + Random Forest and HOG prototype-similarity classifier on our splits
  3. SqueezeNet v1.1 CNN (Tanaka et al., 2023) on the same splits
  4. Objective assessment: accuracy, sensitivity, specificity, precision,
     F1, ROC-AUC with bootstrap 95% CIs, confusion matrices, ROC curves
  5. Interpretation: HOG similarity time course, t-SNE, Grad-CAM

Splits: (a) stratified random 15/42.5/42.5 (Progress Report 1),
        (b) trial-wise shock1/shock2/shock3,
        (c) leave-one-shock-out cross-validation (3 folds).

Example:
  python run_pipeline.py --frames data/tailshock_200uA --crop 350 120 600 500
"""
from __future__ import annotations

import argparse
import json
import sys
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.metrics import ConfusionMatrixDisplay, RocCurveDisplay

from src.config import Config
from src import data as D
from src import features as Fe
from src.metrics import summarize, binary_metrics

plt.rcParams.update({"figure.dpi": 120, "savefig.bbox": "tight", "font.size": 9})
CLASS_NAMES = ["pre-shock", "during-shock"]


def log(*a):
    print(time.strftime("[%H:%M:%S]"), *a, flush=True)


def parse():
    p = argparse.ArgumentParser()
    p.add_argument("--frames", help="folder of frames or a video file")
    p.add_argument("--glob", default=None, help="frame file pattern, e.g. '*.png'")
    p.add_argument("--crop", nargs=4, type=int, metavar=("X", "Y", "W", "H"))
    p.add_argument("--pick-crop", action="store_true", help="draw the crop box and exit")
    p.add_argument("--out", default=None)
    p.add_argument("--skip-cnn", action="store_true")
    p.add_argument("--no-pretrained", action="store_true")
    p.add_argument("--epochs", type=int)
    p.add_argument("--optimizer", choices=["sgd", "adam"])
    p.add_argument("--lr", type=float)
    p.add_argument("--no-loto", action="store_true", help="skip leave-one-shock-out CV")
    p.add_argument("--workers", type=int)
    return p.parse_args()


# ------------------------------------------------------------------ figures
def fig_examples(ds, cfg, X):
    i_pre = np.where((ds.y == 0) & (ds.trial == 0))[0][60]
    i_dur = np.where((ds.y == 1) & (ds.trial == 0))[0][30]
    fig, ax = plt.subplots(2, 2, figsize=(7, 6))
    for c, i in enumerate((i_pre, i_dur)):
        ax[0, c].imshow(ds.images[i], cmap="gray")
        ax[0, c].set_title(f"{CLASS_NAMES[ds.y[i]]} (frame {ds.frame_idx[i]})")
        ax[1, c].imshow(Fe.hog_image(ds.images[i], cfg), cmap="magma")
        ax[1, c].set_title("HOG (8 orient., 32x32 cells)")
    for a in ax.ravel():
        a.axis("off")
    fig.savefig(cfg.out / "fig1_example_frames_hog.png")
    plt.close(fig)


def fig_timecourse(cfg, proto):
    """Pearson r of every frame's HOG with the pain and neutral prototypes."""
    tc = D.load_timecourse(cfg, before=300, after=300)
    fig, ax = plt.subplots(1, 1, figsize=(7, 3))
    rows = []
    for k, (t, imgs) in enumerate(tc):
        S = proto.similarity(Fe.hog_features(imgs, cfg))
        ax.plot(t, S[:, 1], lw=0.5, color="firebrick", alpha=0.25,
                label="r(pain prototype)" if k == 0 else None)
        ax.plot(t, S[:, 0], lw=0.5, color="gray", alpha=0.25,
                label="r(neutral prototype)" if k == 0 else None)
        rows += [{"shock": k + 1, "t_rel": int(a), "r_pain": b, "r_neutral": c}
                 for a, b, c in zip(t, S[:, 1], S[:, 0])]
    # mean across the 3 shocks, lightly smoothed (5-frame running mean)
    tc_df = pd.DataFrame(rows).groupby("t_rel")[["r_pain", "r_neutral"]].mean()
    sm = tc_df.rolling(5, center=True, min_periods=1).mean()
    ax.plot(sm.index, sm.r_pain, color="darkred", lw=2, label="mean r(pain)")
    ax.plot(sm.index, sm.r_neutral, color="black", lw=2, label="mean r(neutral)")
    ax.axvspan(0, cfg.n_during, color="gold", alpha=0.25, label="shock (60 frames)")
    ax.axvspan(-cfg.n_pre, 0, color="lightblue", alpha=0.2, label="pre-shock window")
    ax.set_xlabel("frames relative to shock onset")
    ax.set_ylabel("Pearson r (HOG)")
    ax.set_title("Similarity to prototype faces (3 shocks overlaid)")
    ax.legend(fontsize=6, ncol=3, loc="lower left")
    fig.savefig(cfg.out / "fig2_prototype_similarity_timecourse.png")
    plt.close(fig)
    pd.DataFrame(rows).to_csv(cfg.out / "prototype_similarity_timecourse.csv", index=False)


def fig_tsne(ds, X, cfg):
    Z = PCA(n_components=min(50, X.shape[1], len(X) - 1), random_state=cfg.seed).fit_transform(X)
    E = TSNE(n_components=2, perplexity=30, random_state=cfg.seed, init="pca").fit_transform(Z)
    fig, ax = plt.subplots(figsize=(4.5, 4))
    for c, col in ((0, "lightgray"), (1, "firebrick")):
        for k, m in enumerate("os^"):
            s = (ds.y == c) & (ds.trial == k)
            ax.scatter(E[s, 0], E[s, 1], s=10, c=col, marker=m, edgecolor="k", lw=0.2,
                       label=f"{CLASS_NAMES[c]}, shock {k + 1}")
    ax.legend(fontsize=6)
    ax.set_title("t-SNE of HOG descriptors")
    ax.set_xticks([]); ax.set_yticks([])
    fig.savefig(cfg.out / "fig3_tsne_hog.png")
    plt.close(fig)


def fig_confusions(preds, cfg, split_name):
    models = [m for (m, s) in preds if s == split_name]
    fig, ax = plt.subplots(1, len(models), figsize=(3.2 * len(models), 3))
    ax = np.atleast_1d(ax)
    for a, m in zip(ax, models):
        yt, yp, _ = preds[(m, split_name)]
        ConfusionMatrixDisplay.from_predictions(yt, yp, display_labels=["pre", "during"],
                                                ax=a, colorbar=False, cmap="Blues")
        a.set_title(m, fontsize=8)
    fig.suptitle(f"Confusion matrices - test set ({split_name})")
    fig.savefig(cfg.out / f"fig_confusion_{split_name}.png")
    plt.close(fig)


def fig_rocs(preds, cfg, split_name):
    fig, ax = plt.subplots(figsize=(4, 4))
    for (m, s), (yt, _, sc) in preds.items():
        if s == split_name and sc is not None:
            RocCurveDisplay.from_predictions(yt, sc, name=m, ax=ax)
    ax.plot([0, 1], [0, 1], "k:", lw=0.8)
    ax.set_title(f"ROC - test set ({split_name})")
    ax.legend(fontsize=7)
    fig.savefig(cfg.out / f"fig_roc_{split_name}.png")
    plt.close(fig)


def fig_history(hists, cfg):
    fig, ax = plt.subplots(1, 2, figsize=(8, 3))
    for name, h in hists.items():
        l, = ax[0].plot(h["epoch"], h["train_loss"], label=f"{name} train")
        ax[0].plot(h["epoch"], h["val_loss"], "--", color=l.get_color(), label=f"{name} val")
        ax[1].plot(h["epoch"], h["train_acc"], color=l.get_color())
        ax[1].plot(h["epoch"], h["val_acc"], "--", color=l.get_color())
    ax[0].set_ylabel("cross-entropy"); ax[1].set_ylabel("accuracy")
    for a in ax:
        a.set_xlabel("epoch")
    ax[0].legend(fontsize=6)
    fig.suptitle("SqueezeNet training curves (solid = train, dashed = validation)")
    fig.savefig(cfg.out / "fig_cnn_training_curves.png")
    plt.close(fig)


def fig_gradcam(net, ds, test_idx, probs, cfg):
    from src.gradcam import gradcam
    import cv2
    fig, ax = plt.subplots(2, 5, figsize=(12, 5.2))
    for r, c in enumerate((0, 1)):
        cand = test_idx[ds.y[test_idx] == c]
        # top-5 most confident correct-class frames, as in Tanaka et al.
        conf = probs[np.isin(test_idx, cand)]
        conf = conf if c == 1 else 1 - conf
        order = np.argsort(-conf)[:5]
        top, topconf = cand[order], conf[order]
        maps = gradcam(net, ds.images[top], cfg, target_class=c)
        for j, (i, hm) in enumerate(zip(top, maps)):
            img = cv2.resize(ds.images[i], (cfg.img_size, cfg.img_size))
            ax[r, j].imshow(img, cmap="gray")
            ax[r, j].imshow(hm, cmap="jet", alpha=0.45)
            ax[r, j].set_title(f"{CLASS_NAMES[c]}  p={topconf[j]:.2f}", fontsize=7)
            ax[r, j].axis("off")
    fig.suptitle("Grad-CAM: top-5 most confident test frames per class")
    fig.savefig(cfg.out / "fig_gradcam.png")
    plt.close(fig)


# ------------------------------------------------------------------- main
def main():
    a = parse()
    cfg = Config()
    if a.frames: cfg.frames_source = a.frames
    if a.glob: cfg.frame_glob = a.glob
    if a.crop: cfg.crop = tuple(a.crop)
    if a.out: cfg.out_dir = a.out
    if a.epochs: cfg.cnn_epochs = a.epochs
    if a.optimizer: cfg.cnn_optimizer = a.optimizer
    if a.lr: cfg.cnn_lr = a.lr
    if a.no_pretrained: cfg.cnn_pretrained = False
    if a.workers is not None: cfg.num_workers = a.workers
    if a.pick_crop:
        D.pick_crop(cfg); return

    t0 = time.time()
    log("Loading frames from", cfg.frames_source, "crop =", cfg.crop)
    ds = D.load_shock_dataset(cfg)
    log(f"{len(ds.y)} frames, image size {ds.images.shape[1:]}, "
        f"{(ds.y == 0).sum()} pre / {(ds.y == 1).sum()} during")

    splits = {"stratified": D.split_stratified(ds.y, cfg),
              "trialwise": D.split_trialwise(ds.trial)}
    loto = [] if a.no_loto else D.splits_leave_one_trial_out(ds.y, ds.trial, cfg)
    tabs = []
    for name, sp in splits.items():
        t = D.split_table(ds.y, sp); t.insert(0, "split", name); tabs.append(t)
    for f in loto:
        t = D.split_table(ds.y, f); t.insert(0, "split", f"loto_{f['name']}"); tabs.append(t)
    pd.concat(tabs).to_csv(cfg.out / "split_sizes.csv", index=False)
    print(pd.concat(tabs).to_string(index=False))

    log("Computing HOG descriptors")
    X = Fe.hog_features(ds.images, cfg)
    log("HOG feature length:", X.shape[1])
    fig_examples(ds, cfg, X)

    rows, preds = [], {}

    # ---- 1. exact reproduction of the authors' notebook protocol ----------
    # Train on a random 15% sample, report accuracy on ALL 540 frames
    # (includes the training frames, so this is optimistic by design).
    rng = np.random.default_rng(cfg.seed)
    accs = []
    for rep in range(10):
        tr = rng.choice(len(ds.y), size=int(round(0.15 * len(ds.y))), replace=False)
        rf = Fe.train_rf(X[tr], ds.y[tr], cfg)
        accs.append(binary_metrics(ds.y, rf.predict(X))["accuracy"])
    repro = {"protocol": "authors' notebook: train 15% random, score all 540 frames",
             "accuracy_mean": float(np.mean(accs)), "accuracy_sd": float(np.std(accs)),
             "n_repeats": 10}
    json.dump(repro, open(cfg.out / "paper_reproduction.json", "w"), indent=2)
    log(f"Paper reproduction accuracy: {repro['accuracy_mean']:.3f} +/- {repro['accuracy_sd']:.3f}")

    # ---- 2. HOG + RF / prototype on held-out test sets --------------------
    def eval_hog_models(sp, split_name):
        tr, te = sp["train"], sp["test"]
        rf = Fe.train_rf(X[tr], ds.y[tr], cfg)
        sc = rf.predict_proba(X[te])[:, 1]
        yp = (sc >= 0.5).astype(int)
        preds[("HOG+RF", split_name)] = (ds.y[te], yp, sc)
        rows.append(summarize("HOG+RF (Dolensek)", split_name, ds.y[te], yp, sc))
        pc = Fe.PrototypeClassifier().fit(X[tr], ds.y[tr])
        sc = pc.decision_function(X[te])
        preds[("HOG prototype", split_name)] = (ds.y[te], pc.predict(X[te]), sc)
        rows.append(summarize("HOG prototype r (Dolensek)", split_name, ds.y[te],
                              pc.predict(X[te]), sc))
        return rf, pc

    log("HOG models")
    _, proto_strat = eval_hog_models(splits["stratified"], "stratified")
    eval_hog_models(splits["trialwise"], "trialwise")
    for f in loto:
        eval_hog_models(f, f"loto_{f['name']}")

    log("Similarity time course + t-SNE")
    fig_timecourse(cfg, proto_strat)
    fig_tsne(ds, X, cfg)

    # ---- 3. CNN ----------------------------------------------------------
    hists = {}
    if not a.skip_cnn:
        from src.cnn import train_cnn, predict_cnn, device
        import torch
        log("CNN device:", device())

        def eval_cnn(sp, split_name, keep=False):
            log(f"Training SqueezeNet on split '{split_name}'")
            net, h = train_cnn(ds.images, ds.y, sp, cfg)
            hists[split_name] = h
            yp, p = predict_cnn(net, ds.images[sp["test"]], cfg)
            preds[("SqueezeNet", split_name)] = (ds.y[sp["test"]], yp, p)
            rows.append(summarize("SqueezeNet v1.1 CNN (Tanaka)", split_name,
                                  ds.y[sp["test"]], yp, p))
            if keep:
                torch.save(net.state_dict(), cfg.out / f"squeezenet_{split_name}.pt")
            return net, p

        net, p = eval_cnn(splits["stratified"], "stratified", keep=True)
        try:
            fig_gradcam(net, ds, splits["stratified"]["test"], p, cfg)
        except Exception as e:
            log("Grad-CAM failed:", e)
        eval_cnn(splits["trialwise"], "trialwise", keep=True)
        for f in loto:
            eval_cnn(f, f"loto_{f['name']}")
        fig_history({k: v for k, v in hists.items() if not k.startswith("loto")}, cfg)

    # ---- 4. results tables ----------------------------------------------
    res = pd.DataFrame(rows)
    res.to_csv(cfg.out / "results_all.csv", index=False)
    for s in ("stratified", "trialwise"):
        fig_confusions(preds, cfg, s); fig_rocs(preds, cfg, s)

    num = ["accuracy", "balanced_accuracy", "sensitivity", "specificity",
           "precision_shock", "f1_shock", "roc_auc"]
    main_tab = res[res.split.isin(["stratified", "trialwise"])][["model", "split"] + num]
    main_tab.round(3).to_csv(cfg.out / "results_main.csv", index=False)
    if loto:
        lo = res[res.split.str.startswith("loto")]
        g = lo.groupby("model")[num].agg(["mean", "std"]).round(3)
        g.to_csv(cfg.out / "results_loto_summary.csv")
    print("\n=== Held-out test results ===")
    print(main_tab.round(3).to_string(index=False))
    if loto:
        print("\n=== Leave-one-shock-out CV (mean, sd over 3 folds) ===")
        print(g.to_string())
    log(f"Done in {time.time() - t0:.0f}s. Outputs in {cfg.out.resolve()}")


if __name__ == "__main__":
    sys.exit(main())
